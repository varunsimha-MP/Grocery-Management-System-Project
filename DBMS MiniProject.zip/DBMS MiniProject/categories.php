<?php
session_start();

if (isset($_SESSION['login'])) {
  $mail=$_SESSION['mail'];
    $fname = $_SESSION['fname'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>SRI VENKATESHWARA ENTERPRISES</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <div class="container mt-3">
    <div class="mt-3 p-3 bg-success text-white rounded">
      <center>
      <h1>SRI VENKATESHWARA ENTERPRISES</h1>
    </center>
    </div>
  <hr>
                  <ul class="nav nav-pills">
                    <li class="nav-item">
                      <a href="customerpage.php" class="btn btn-outline-success"><b>Main Page</b></a>
                    </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
            <li class="nav-item dropdown">
              <?php
              $servername = "localhost";
              $username = "root";
              $password = "";
              $dbname = "dbmsminiproject";

              $conn = mysqli_connect($servername, $username, $password, $dbname);

              if(!$conn){
                die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
              }?>
              <?php
                $sql = "SELECT distinct stype FROM stock";
                $result = $conn->query($sql);
                  $row = mysqli_num_rows($result);
                  ?>
              <a class="nav-link dropdown-toggle text-success" data-bs-toggle="dropdown">Categories</a>
              <ul class="dropdown-menu">
                <?php
                    while($rows=mysqli_fetch_assoc($result)){
                ?>
                <li><a class="dropdown-item text-success" href="categories.php?stype=<?php echo $rows['stype'] ;?>"> <?php echo $rows['stype'] ;?></a></li>
              <?php }
              ?>
              </ul>
            </li>
		<li class="nav-item">
			<a>&nbsp;</a>
		</li>
		<li class="nav-item">
			<a>&nbsp;</a>
		</li><li class="nav-item">
      <a href="addcardpage.php" class="btn btn-outline-success"><b>Add To Cart</b></a>
    </li>
    <li class="nav-item">
      <a>&nbsp;</a>
    </li>
    <li class="nav-item">
      <a>&nbsp;</a>
    </li>
                <li class="nav-item">
                  <a href="buy.php" class="btn btn-outline-success"><b>Pruchase History</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
								<li class="nav-item">
                  <a href="customerpageinfo.php" class="btn btn-outline-success"><b>Customer Details</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="feedback.php" class="btn btn-outline-success"><b>Feedback</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="customerlogout.php" class="btn btn-outline-danger"><b>Logout</b></a>
                </li>
              </ul>
<hr>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbmsminiproject";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if(!$conn){
  die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
}
$stype = $_GET["stype"];
$sql="SELECT * FROM stock WHERE stype='$stype'";
$result = mysqli_query($conn,$sql);
?>
<h5 class="text-center text-success">Customer E-Mail Id:<?php echo $mail;?></h5>
<hr>
<div class="row sm-4">
              <?php
            while($rows=mysqli_fetch_assoc($result)){
        ?>
              <div class="col-sm-4">
                  <div class="table-responsive-sm">
                  <table class="table table-hover table-sm table-striped table-condensed table-bordered">
                    <tr>
                      <td class="text-success py-2"><h3><b><?php echo $rows['stype']?></b></h3></td>
                    </tr>
                    <tr>
                      <td class="text-center py-2"><?php echo "<img src='".$rows['simage']."' style='width:200px',height:200px;>" ?></td>
                    </tr>
                    <tr>
                      <td class="py-2"><b>Item Name: <?php echo $rows['sname']?></b></td>
                    </tr>
                    <tr>
                      <td class="py-2"><b>Rate Per Item: &#x20B9;<?php echo $rows['srate']?></b></td>
                    </tr>
                    <tr>
                      <td><form method="post" action="addcard.php">
                        <input type="hidden" id="mail" name="mail" value="<?php echo $mail;?>">
                        <input type="hidden" id="sname" name="sname" value="<?php echo $rows['sname']?>">
                        <input type="number" min="1" id="quantity" name="quantity" placeholder="Quantity" required>&nbsp;&nbsp;
                        <input type="hidden" id="srate" name="srate" value="<?php echo $rows['srate']?>">
                        <input type="hidden" id="status" name="status" value="To be Deliver">
                        <input type="hidden" id="cash" name="cash" value="Cash On Delivery">
                        <input type="submit" value="Add To Cart"></form></td>
</tr>
                  </table>
                </div>
              </div>
            <?php } ?>
</div>
</body>
</html>
<?php

} else {
    header("location:customerpage.php ");
}
?>
