<?php
    $servername="localhost";
    $username = "root";
    $password = "";
    $dbname = "dbmsminiproject";
    $conn=new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error){
      die("connection failed!".$conn->connect_error);
    }
    $mail = $_GET["mail"];
    $sql="INSERT INTO purchasehistory(mail,sname,quantity,srate,amount,status,cash) select cd.mail,sname,quantity,srate,amount,status,cash from card,customerdetails cd where cd.mail='$mail'";
      if($conn->query($sql)===TRUE){
        $sql2 = "DELETE FROM card WHERE mail='$mail'";
      if($conn->query($sql2)===TRUE){
      header("Location:buy.php?message=successfully");
    }else{
      header("Location:buy.php?message=error");
    }
  }
    $conn->close();
    ?>
