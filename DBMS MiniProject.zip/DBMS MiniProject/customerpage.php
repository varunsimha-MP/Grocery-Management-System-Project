<?php
session_start();

if (isset($_SESSION['login'])) {
   $mail = $_SESSION['mail'];
    $fname = $_SESSION['fname'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>SRI VENKATESHWARA ENTERPRISES</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <div class="container mt-3">
    <div class="mt-3 p-3 bg-success text-white rounded">
      <center>
      <h1>SRI VENKATESHWARA ENTERPRISES</h1>
    </center>
    </div>
  <hr>
  <ul class="nav nav-pills">
                    <li class="nav-item">
                      <a href="customerpage.php" class="btn btn-outline-success"><b>Main Page</b></a>
                    </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
							<li class="nav-item dropdown">
			          <?php
			          $servername = "localhost";
			          $username = "root";
			          $password = "";
			          $dbname = "dbmsminiproject";

			          $conn = mysqli_connect($servername, $username, $password, $dbname);

			          if(!$conn){
			            die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
			          }?>
			          <?php
			            $sql = "SELECT distinct stype FROM stock";
			            $result = $conn->query($sql);
			              $row = mysqli_num_rows($result);
			              ?>
			          <a class="nav-link dropdown-toggle text-success" data-bs-toggle="dropdown">Categories</a>
			          <ul class="dropdown-menu">
			            <?php
			                while($rows=mysqli_fetch_assoc($result)){
			            ?>
			            <li><a class="dropdown-item text-success" href="categories.php?stype=<?php echo $rows['stype'] ;?>"> <?php echo $rows['stype'] ;?></a></li>
			          <?php }
			          ?>
			          </ul>
			        </li>
		<li class="nav-item">
			<a>&nbsp;</a>
		</li>
		<li class="nav-item">
			<a>&nbsp;</a>
		</li>
  </li><li class="nav-item">
    <a href="addcardpage.php" class="btn btn-outline-success"><b>Add To Cart</b></a>
  </li>
  <li class="nav-item">
    <a>&nbsp;</a>
  </li>
  <li class="nav-item">
    <a>&nbsp;</a>
  </li>
                <li class="nav-item">
                  <a href="buy.php" class="btn btn-outline-success"><b>Purchase History</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
								<li class="nav-item">
                  <a href="customerpageinfo.php" class="btn btn-outline-success"><b>Customer Details</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="feedback.php" class="btn btn-outline-success"><b>Feedback</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="changepassword.php" class="btn btn-outline-danger"><b>Change Password</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="customerlogout.php" class="btn btn-outline-danger"><b>Logout</b></a>
                </li>
              </ul>
<hr>
<?php
if(isset($_GET["message"])){
  if($_GET["message"]=="successfully")
  {?>
    <div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <b>Successfully Login.</b></div>
      <?php }
}
    ?>
    <?php
    if(isset($_GET["message"])){
      if($_GET["message"]=="changepasswordsuccessfully")
      {?>
        <div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <b>Password has been changed Successfully.</b></div>
          <?php }
    }
        ?>
    <h5 class="text-center text-success">Customer E-Mail Id:<?php echo $mail;?></h5>
    <hr>

<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="3"></button>
  </div>

  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="3.jpeg" alt="SRI VENKATESHWARA ENTERPRISES" class="img-thumbnail mx-auto d-block rounded" style="width:1000px">
    </div>
    <div class="carousel-item">
  <img src="2.jpeg" alt="SRI VENKATESHWARA ENTERPRISES" class="img-thumbnail mx-auto d-block rounded" style="width:650px">
    </div>
    <div class="carousel-item">
    <img src="1.jpeg" alt="SRI VENKATESHWARA ENTERPRISES" class="img-thumbnail mx-auto d-block rounded" style="width:700px">
    </div>
    <div class="carousel-item">
      <img src="4.jpeg" alt="SRI VENKATESHWARA ENTERPRISES" class="img-thumbnail mx-auto d-block rounded" style="width:500px">
    </div>
  </div>

  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<hr>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbmsminiproject";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if(!$conn){
  die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
}
$sql="SELECT * FROM stock order by stype";
$result = mysqli_query($conn,$sql);
?>
<div class="row sm-4">
              <?php
            while($rows=mysqli_fetch_assoc($result)){
        ?>
              <div class="col-sm-4">
                  <div class="table-responsive-sm">
                  <table class="table table-hover table-sm table-striped table-condensed table-bordered">
                    <tr>
                      <td class="text-success py-2"><h3><b><?php echo $rows['stype']?></b></h3></td>
                    </tr>
                    <tr>
                      <td class="text-center py-2"><?php echo "<img src='".$rows['simage']."' style='width:200px',height:200px;>" ?></td>
                    </tr>
                    <tr>
                      <td class="py-2"><b>Item Name: <?php echo $rows['sname']?></b></td>
                    </tr>
                    <tr>
                      <td class="py-2"><b>Rate Per Item: &#x20B9;<?php echo $rows['srate']?></b></td>
                    </tr>
                    <tr>
                      <td><form method="post" action="addcard.php">
                        <input type="hidden" id="mail" name="mail" value="<?php echo $mail;?>">
                        <input type="hidden" id="sname" name="sname" value="<?php echo $rows['sname']?>">
                        <input type="number" min="1" id="quantity" name="quantity" placeholder="Quantity" required>&nbsp;&nbsp;
                        <input type="hidden" id="srate" name="srate" value="<?php echo $rows['srate']?>">
                        <input type="hidden" id="status" name="status" value="To be Deliver">
                        <input type="hidden" id="cash" name="cash" value="Cash On Delivery">
                        <input type="submit" value="Add To Cart"></form></td>
</tr>
                  </table>
                </div>
              </div>
            <?php } ?>
</div>
<div class="container">
<div class="bg-dark text-white rounded">
  <center>
  <p>Copyright &copy; 2021 DBP2021-A14(Varunsimha M P & Ventakraman G). All rights reserved.</p>
</center>
</div>
</div>
</body>
</html>
<?php

} else {
    header("location:customerpage.php ");
}
?>
