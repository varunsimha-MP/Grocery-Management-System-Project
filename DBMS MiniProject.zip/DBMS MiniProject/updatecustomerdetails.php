<?php
$servername="localhost";
$username="root";
$password="";
$dbname="dbmsminiproject";

$pnumber=val($_POST["pnumber"]);
$paddress=val($_POST["paddress"]);
$caddress=val($_POST["caddress"]);
$id=val($_POST["id"]);
function val($data){
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
  die("Connection failed".$conn->connect_error);
}
$sql="UPDATE customerdetails SET pnumber='$pnumber',paddress='$paddress',waddress='$waddress' WHERE id='$id' ";
if($conn->query($sql)===TRUE){
header("location:customerpageinfo.php?message=updatesuccessfully");
}
else {
  echo "ERROR".$conn->error;
  $conn->close();
}
?>
