<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbmsminiproject";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET["id"];

$sql = "DELETE FROM stock WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    header("Location:managerpage.php?message=delete");
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
