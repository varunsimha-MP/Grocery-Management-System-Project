<?php
session_start();

if (isset($_SESSION['login'])) {
  $mail = $_SESSION['mail'];
   $fname = $_SESSION['fname'];

?>

<!DOCTYPE html>
<html>
<head>
  <title>SRI VENKATESHWARA ENTERPRISES</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
<center>
<div class="container">
      <div class="row">
        <div class="col-11 mt-3 p-3 bg-success text-white rounded">

          <h1>SRI VENKATESHWARA ENTERPRISES</h1>
        </div>
        <div class="col-1 mt-3 p-3">
      <h1><a href="managerlogout.php" class="btn btn-outline-danger"><b>Logout</b></a> </h1>
             </div>
      </div>
    </div>
    <div class="container">
  <hr>
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a href="managerpage.php" class="btn btn-outline-success"><b>Main Page</b></a>
            </li>
        <li class="nav-item">
          <a>&nbsp;</a>
        </li>
        <li class="nav-item">
          <a>&nbsp;</a>
        </li>
        <li class="nav-item">
          <a href="stock.php" class="btn btn-outline-success"><b>Upload Stock</b></a>
        </li>
    <li class="nav-item">
      <a>&nbsp;</a>
    </li>
    <li class="nav-item">
      <a>&nbsp;</a>
    </li>
    <li class="nav-item">
      <a href="deliverystatus.php" class="btn btn-outline-success"><b>Delivery Status</b></a>
    </li><li class="nav-item">
          <a>&nbsp;</a>
        </li>
        <li class="nav-item">
          <a>&nbsp;</a>
        </li>
        <li class="nav-item dropdown">
          <?php
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "dbmsminiproject";

          $conn = mysqli_connect($servername, $username, $password, $dbname);

          if(!$conn){
            die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
          }
            $sql = "SELECT * FROM stock";
            $result = $conn->query($sql);
              $row = mysqli_num_rows($result);
              ?>
          <a class="nav-link dropdown-toggle text-success" data-bs-toggle="dropdown">Update Stock</a>
          <ul class="dropdown-menu">
            <?php
                while($rows=mysqli_fetch_assoc($result)){
            ?>
            <li><a class="dropdown-item text-success" href="updatestockform.php?id= <?php echo $rows['id'] ;?>"> <?php echo $rows['sname'] ;?>(<?php echo $rows['stype'] ;?>)</a></li>
          <?php }
          ?>
          </ul>
        </li>
        <li class="nav-item">
          <a href="itemsoldhistory.php" class="btn btn-outline-success"><b>Sold History</b></a>
        </li><li class="nav-item">
              <a>&nbsp;</a>
            </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
            <?php
              $sql = "SELECT * FROM stock";
              $result = $conn->query($sql);
                $row = mysqli_num_rows($result);
                ?>
            <a class="nav-link dropdown-toggle text-danger" data-bs-toggle="dropdown">Remove Stock</a>
            <ul class="dropdown-menu">
              <?php
                  while($rows=mysqli_fetch_assoc($result)){
              ?>
              <li><a class="dropdown-item text-danger" href="deletestock.php?id=<?php echo $rows['id'] ;?>"> <?php echo $rows['sname'] ;?>(<?php echo $rows['stype'] ;?>)</a></li>
            <?php }
            ?>
            </ul>
          </li>
          <li class="nav-item">
                <a>&nbsp;</a>
              </li>
              <li class="nav-item">
                <a>&nbsp;</a>
              </li>
        <li class="nav-item">
          <a href="feedbackretrive.php" class="btn btn-outline-success"><b>Customer Feedback</b></a>
        </li>
<hr>
</div>
<div class="container">
<?php
if(isset($_GET["message"])){
  if($_GET["message"]=="successfully")
  {?>
    <div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <b>New Stock Loaded Successfully</b></div>
      <?php }
}?>
<?php
if(isset($_GET["message"])){
  if($_GET["message"]=="updatesuccessfully")
  {?>
    <div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <b>Stock Update Successfully</b></div>
      <?php }
}
    ?>
    <?php
    if(isset($_GET["message"])){
      if($_GET["message"]=="error")
      {?>
        <div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <b>Failed to Load Stock</b></div>
          <?php }
    }
        ?>
        <?php
        if(isset($_GET["message"])){
          if($_GET["message"]=="delete")
          {?>
            <div class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <b>Successfully Delete Stock</b></div>
              <?php }
        }
            ?>
            <hr>
            <h1 class="text-center text-success">Welcome to Admin(<?php echo $fname;?>)</h1>
                    <h3 class="text-center">Store Customers</h3>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dbmsminiproject";

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if(!$conn){
          die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
        }?>
        <?php
          $sql = "SELECT * FROM customerdetails";
          $result = $conn->query($sql);
            $row = mysqli_num_rows($result);
            ?>
            <div class="row">
                <div class="col">
                    <div class="table-responsive-sm">
                    <table class="table table-hover table-sm table-striped table-condensed table-bordered" style="border-color:black;">
                        <thead style="color : black;">
                            <tr>
            <td class="text-center py-2"><b>Total Number of Customers</b></td>
            <td class="text-center py-2"><b><?php echo $row ?></b></td>
            </tr>
          </thead>
          </table>
          <?php
          $sql = "SELECT * FROM customerdetails";
          $result = mysqli_query($conn,$sql);
      ?>
                  <div class="row">
                      <div class="col">
                          <div class="table-responsive-sm">
                          <table class="table table-hover table-sm table-striped table-condensed table-bordered" style="border-color:black;">
                              <thead style="color : black;">
                                  <tr>
                                  <th class="text-center py-2">Id</th>
                                  <th class="text-center py-2">Full Name</th>
                                  <th class="text-center py-2">Phone Number</th>
                                  <th class="text-center py-2">Mail-ID</th>
                                  <th class="text-center py-2">Home Address</th>
                                  <th class="text-center py-2">Work Place</th>
                                  <th class="text-center py-2">View</th>
                                  </tr>
                              </thead>
                              <tbody>
                      <?php
                          while($rows=mysqli_fetch_assoc($result)){
                      ?>
                          <tr style="color : black;">
                              <td class="text-center py-2"><?php echo $rows['id']?></td>
                              <td class="text-center py-2"><?php echo $rows['fname']?></td>
                              <td class="text-center py-2"><?php echo $rows['pnumber']?></td>
                              <td class="text-center py-2"><?php echo $rows['mail']?></td>
                              <td class="text-center py-2"><?php echo $rows['paddress']?></td>
                              <td class="text-center py-2"><?php echo $rows['waddress']?></td>
                              <td class="text-center py-2"><a href="viewcustomerpurchase.php?mail=<?php echo $rows['mail'];?>"> <button type="button" class="btn btn-outline-success"><b>View Purchase History</b></button></a>
                            </td>
                          </tr>
                      <?php
                          }
                      ?>

                              </tbody>
                          </table>
                        </div>
                      </div>
                  </div>
               </div>
               <div>
               <div class="bg-dark text-white rounded">
                 <center>
                 <p>Copyright &copy; 2021 DBP2021-A14(Varunsimha M P & Venkatraman G). All rights reserved.</p>
               </center>
               </div>
             </div>
</body>

</html>

<?php

} else {
    header("location:managerlogin.php ");
}
?>
