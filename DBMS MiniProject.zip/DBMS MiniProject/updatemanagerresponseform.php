<?php
$servername="localhost";
$username="root";
$password="";
$dbname="dbmsminiproject";

$response=val($_POST["response"]);
$id=val($_POST["id"]);

function val($data){
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
  die("Connection failed".$conn->connect_error);
}
$sql="UPDATE feedback SET response='$response' WHERE id='$id' ";
if($conn->query($sql)===TRUE){
header("location:feedbackretrive.php");
}
else {
  echo "ERROR".$conn->error;
  $conn->close();
}
?>
