<?php
$mail=val($_POST["mail"]);
$sname=val($_POST["sname"]);
$quantity=val($_POST["quantity"]);
$srate=val($_POST["srate"]);
$status=val($_POST["status"]);
$cash=val($_POST["cash"]);
$amount = $srate * $quantity;
function val($data){
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}
$servername="localhost";
$username="root";
$password="";
$dbname="dbmsminiproject";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
  die("Connection failed".$conn->connect_error);
}

$sql="INSERT INTO card (mail,sname,quantity,srate,amount,status,cash)VALUES('$mail','$sname','$quantity','$srate','$amount','$status','$cash')";
if($conn->query($sql)===TRUE){
  header("Location:addcardpage.php");
}else{
  header("Location:addcardpage.php");
}
$conn->close();
?>
