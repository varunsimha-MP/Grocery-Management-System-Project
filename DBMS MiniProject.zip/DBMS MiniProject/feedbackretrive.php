<?php
session_start();

if (isset($_SESSION['login'])) {

    $fname = $_SESSION['fname'];
    $mail = $_SESSION['mail'];

?>

<!DOCTYPE html>
<html>
<head>
  <title>SRI VENKATESHWARA ENTERPRISES</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
<center>
  <div class="container mt-3">
    <div class="mt-3 p-3 bg-success text-white rounded">
      <center>
      <h1>SRI VENKATESHWARA ENTERPRISES</h1>
    </center>
    </div>
  <hr>
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a href="managerpage.php" class="btn btn-outline-success"><b>Main Page</b></a>
            </li>
        <li class="nav-item">
          <a>&nbsp;</a>
        </li>
        <li class="nav-item">
          <a>&nbsp;</a>
        </li>
        <li class="nav-item">
          <a href="itemsoldhistory.php" class="btn btn-outline-success"><b>Sold History</b></a>
        </li>
        <li class="nav-item">
  

        </div>
<div class="container mt-3">
  <hr>
</div>
            <div class="container">
                    <h1 class="text-center text-success">Customers Review</h1>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dbmsminiproject";

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if(!$conn){
          die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
        }?>
          <?php
          $sql = "SELECT * FROM feedback";
          $result = mysqli_query($conn,$sql);
      ?>
                  <div class="row">
                      <div class="col">
                          <div class="table-responsive-sm">
                          <table class="table table-hover table-sm table-striped table-condensed table-bordered" style="border-color:black;">
                              <thead style="color : black;">
                                  <tr>
                                  <th class="text-center py-2">Customer Account ID</th>
                                  <th class="text-center py-2">Customer Name</th>
                                  <th class="text-center py-2">Comment</th>
                                  <th class="text-center py-2">Customer Review</th>
                                  <th class="text-center py-2">Manager Response</th>
                                  <th class="text-center py-2">Update Response</th>

                                  </tr>
                              </thead>
                              <tbody>
                      <?php
                          while($rows=mysqli_fetch_assoc($result)){
                      ?>
                          <tr style="color : black;">
                              <td class="text-center py-2"><?php echo $rows['mail']?></td>
                              <td class="text-center py-2"><?php echo $rows['fname']?></td>
                              <td class="text-center py-2"><?php echo $rows['comment']?></td>
                              <td class="text-center py-2"><?php echo $rows['star']?></td>
                              <td class="text-center py-2"><?php echo $rows['response']?> </td>
                              <td><a href="managerresponseform.php?id=<?php echo $rows['id'] ;?>"> <button type="button" class="btn btn-outline-success"><b>Update</b></button></a></td>


                          </tr>
                      <?php
                          }
                      ?>

                              </tbody>
                          </table>
                        </div>
                      </div>
                  </div>
               </div>
             </body>

</html>

<?php

} else {
    header("location:managerlogin.php ");
}
