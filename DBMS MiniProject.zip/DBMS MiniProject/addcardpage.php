<?php
session_start();

if (isset($_SESSION['login'])) {
   $mail = $_SESSION['mail'];
    $fname = $_SESSION['fname'];
?>
<!DOCTYPE html>
<html>
<head>
  <title>SRI VENKATESHWARA ENTERPRISES</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<center>
  <div class="container mt-3">
    <div class="mt-3 p-3 bg-success text-white rounded">
      <center>
      <h1>SRI VENKATESHWARA ENTERPRISES</h1>
    </center>
    </div>
  <hr>
            <ul class="nav nav-pills">
                    <li class="nav-item">
                      <a href="customerpage.php" class="btn btn-outline-success"><b>Main Page</b></a>
                    </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
            <li class="nav-item">
              <a>&nbsp;</a>
            </li>
							<li class="nav-item dropdown">
			          <?php
			          $servername = "localhost";
			          $username = "root";
			          $password = "";
			          $dbname = "dbmsminiproject";

			          $conn = mysqli_connect($servername, $username, $password, $dbname);

			          if(!$conn){
			            die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
			          }?>
			          <?php
			            $sql = "SELECT distinct stype FROM stock";
			            $result = $conn->query($sql);
			              $row = mysqli_num_rows($result);
			              ?>
			          <a class="nav-link dropdown-toggle text-success" data-bs-toggle="dropdown">Categories</a>
			          <ul class="dropdown-menu">
			            <?php
			                while($rows=mysqli_fetch_assoc($result)){
			            ?>
			            <li><a class="dropdown-item text-success" href="categories.php?stype=<?php echo $rows['stype'] ;?>"> <?php echo $rows['stype'] ;?></a></li>
			          <?php }
			          ?>
			          </ul>
			        </li>
		<li class="nav-item">
			<a>&nbsp;</a>
		</li>
		<li class="nav-item">
			<a>&nbsp;</a>
		</li>
                <li class="nav-item">
                  <a href="buy.php" class="btn btn-outline-success"><b>Purchase History</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
								<li class="nav-item">
                  <a href="customerpageinfo.php" class="btn btn-outline-success"><b>Customer Details</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="feedback.php" class="btn btn-outline-success"><b>Feedback</b></a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a>&nbsp;</a>
                </li>
                <li class="nav-item">
                  <a href="customerlogout.php" class="btn btn-outline-danger"><b>Logout</b></a>
                </li>
              </ul>
<hr>
            <h5 class="text-center text-success">Customer Id:<?php echo $mail;?></h5>
            <hr>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "dbmsminiproject";

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if(!$conn){
          die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
        }?>
        <?php
          $sql = "SELECT * FROM card where mail='$mail'";
          $result = $conn->query($sql);
            $row = mysqli_num_rows($result);
            ?>
            <div class="row">
                <div class="col">
                    <div class="table-responsive-sm">
                    <table class="table table-hover table-sm table-striped table-condensed table-bordered" style="border-color:black;">
                        <thead style="color : black;">
                            <tr>
            <td class="text-center py-2"><b>Total Number of Item in Cart</b></td>
            <td class="text-center py-2"><b><?php echo $row ?></b></td>
            </tr>
          </thead>
          </table>

                  <div class="row">
                      <div class="col">
                          <div class="table-responsive-sm">
                          <table class="table table-hover table-sm table-striped table-condensed table-bordered" style="border-color:black;">
                              <thead style="color : black;">
                                  <tr>
                                  <th class="text-center py-2">Item Name</th>
                                  <th class="text-center py-2">Quantity</th>
                                  <th class="text-center py-2">Per Item Rate</th>
                                  <th class="text-center py-2">Amount</th>
                                  <th class="text-center py-2">Payment Mode</th>
                                  <th class="text-center py-2">To Remove</th>
                                  </tr>
                              </thead>
                              <tbody>        <?php
                                      $sql = "SELECT * FROM card where mail='$mail'";
                                      $result = mysqli_query($conn,$sql);
                                  ?>
                      <?php
                          while($rows=mysqli_fetch_assoc($result)){
                      ?>
                          <tr style="color : black;">
                              <td class="text-center py-2"><?php echo $rows['sname']?></td>
                              <td class="text-center py-2"><?php echo $rows['quantity']?></td>
                              <td class="text-center py-2">&#x20B9;<?php echo $rows['srate']?></td>
                              <td class="text-center py-2">&#x20B9;<?php echo $rows['amount']?></td>
                              <td class="text-center py-2"><?php echo $rows['cash']?></td>
                              <td class="text-center py-2"><a href="deletecard.php?id=<?php echo $rows["id"]?>"><button type="button" class="btn btn-outline-danger"><b>Delete Item</b></button></a>
                            </td>
                        </tr>
                       <?php } ?>
                        <tr>
                          <th class="text-center py-2">&nbsp;</th>
                          <th class="text-center py-2">&nbsp;</th>
                          <th class="text-center py-2">Total Amount</th>
                          <?php
                                  $sql = "SELECT sum(amount),mail FROM card where mail='$mail'";
                                  $result = mysqli_query($conn,$sql);
                                  $rows=mysqli_fetch_assoc($result);
                              ?>
                              <th class="text-center py-2">&#x20B9;<?php echo $rows['sum(amount)']?></th>
                              <th class="text-center py-2">&nbsp;</th>
                              <td class="text-center py-2"><a href="buynow.php?mail=<?php echo $rows["mail"]?>"><button type="button" class="btn btn-outline-success"><b>Buy Now</b></button></a>

                        </tr>
                              </tbody>
                          </table>
                        </div>
                      </div>
                  </div>
             </div>

</body>
</html>
<?php

} else {
    header("location:customerpage.php ");
}
?>
