<?php
$mail=val($_POST["mail"]);
$fname=val($_POST["fname"]);
$comment=val($_POST["comment"]);
$star=val($_POST["star"]);
$response=val($_POST["response"]);
function val($data){
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}
$servername="localhost";
$username="root";
$password="";
$dbname="dbmsminiproject";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
  die("Connection failed".$conn->connect_error);
}
$sql="INSERT INTO feedback (mail,fname,comment,star,response)VALUES('$mail','$fname','$comment','$star','$response')";
if($conn->query($sql)===TRUE){
  header("Location:feedback.php?message=successfully");
}else{
  header("Location:feedback.php?message=error");
}
$conn->close();
?>
