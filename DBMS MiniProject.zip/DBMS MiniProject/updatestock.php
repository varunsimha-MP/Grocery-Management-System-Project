<?php
$servername="localhost";
$username="root";
$password="";
$dbname="dbmsminiproject";

$stype=val($_POST["stype"]);
$sname=val($_POST["sname"]);
$simage=val($_POST["simage"]);
$srate=val($_POST["srate"]);
$id=val($_POST["id"]);
function val($data){
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
  die("Connection failed".$conn->connect_error);
}
$sql="UPDATE stock SET stype='$stype',sname='$sname',simage='$simage',srate='$srate' WHERE id='$id' ";
if($conn->query($sql)===TRUE){
header("location:managerpage.php?message=updatesuccessfully");
}
else {
  echo "ERROR".$conn->error;
  $conn->close();
}
?>
