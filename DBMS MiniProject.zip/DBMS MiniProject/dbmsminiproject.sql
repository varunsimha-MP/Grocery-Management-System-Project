-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2022 at 07:19 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbmsminiproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `id` int(255) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `quantity` int(10) NOT NULL,
  `srate` int(10) NOT NULL,
  `amount` int(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `cash` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customerdetails`
--

CREATE TABLE `customerdetails` (
  `id` int(255) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `pnumber` int(10) NOT NULL,
  `mail` varchar(40) NOT NULL,
  `paddress` varchar(60) NOT NULL,
  `waddress` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerdetails`
--

INSERT INTO `customerdetails` (`id`, `fname`, `pnumber`, `mail`, `paddress`, `waddress`) VALUES
(8, 'Varunsimha M P', 1234567890, 'simha@gmail.com', '#82/1 3rd cross irwin road', 'wsdfghj'),
(9, 'Venkatraman G', 1234567890, 'venky1@gmail.com', '#82/1 3rd cross irwin road', ''),
(10, 'Venkatraman G', 1234567890, 'venky@gmail.com', '#82/1 3rd cross irwin road', ''),
(11, 'Venkatraman G', 1234567890, 'venky12@gmail.com', '#82/1 3rd cross irwin road', ''),
(12, 'simha', 1234567890, 'simha123@gmail.com', '#82/1 3rd cross irwin road', ''),
(13, 'Venkatraman G', 1234567890, 'varunsimha90@gmail.com', '#82/1 3rd cross irwin road', ''),
(14, 'Venkatraman G', 1234567890, 'venky100000@gmail.com', '#82/1 3rd cross irwin road', '');

-- --------------------------------------------------------

--
-- Table structure for table `customerid`
--

CREATE TABLE `customerid` (
  `id` int(255) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `mail` varchar(30) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerid`
--

INSERT INTO `customerid` (`id`, `fname`, `mail`, `password`) VALUES
(24, 'Varunsimha M P', 'simha@gmail.com', '$2y$12$wtGGpMVVoq9edgyMBtLu8uoczx.J7d5lHBsc2vAKqkWmlC1lVs3SS'),
(25, 'Venkatraman G', 'venky1@gmail.com', '$2y$12$Xf8TygPIkUgCWaZSLlWNL.PzrieJcmlDxWv5nEgSKt9FA1/QGrL62'),
(26, 'Venkatraman G', 'venky@gmail.com', '$2y$12$W2QYsPyWUcy.inOKO6DxJ.OghY.vtOF.c15vxpDmj7irVPeF2LWlC'),
(27, 'Venkatraman G', 'venky12@gmail.com', '$2y$12$DXmeSHC4tuv4SZ2zCt.ak.UNc.xx5pAzoLGL3e1ZExB8nfgDHiJRe'),
(28, 'simha', 'simha123@gmail.com', '$2y$12$JZv3u84KrWTEJSDkJICmmOnObmpcE4PusZhobLg5qkA6SrXpxfUJq'),
(29, 'Venkatraman G', 'varunsimha90@gmail.com', '$2y$12$V2npHLBKerNJyforvFxUDehx0ylk7dxgVmmAzC.sM9HTUGnwjhXiO'),
(30, 'Venkatraman G', 'venky100000@gmail.com', '$2y$12$dE9H/dCp7wlqOKaLAPbwf..zmWE7RUG9aN1W6nBUVYuLOxw1Jlmku');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(255) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `fname` varchar(40) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `star` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `mail`, `fname`, `comment`, `star`) VALUES
(1, 'varunsimha@gmail.com', '', 'serdcftvgbhjnkm', 5),
(2, 'varunsimha@gmail.com', '', 'wefrgth', 4),
(3, 'varunsimha@gmail.com', 'Varunsimha', 'hjbgvhjk', 5),
(4, 'venky100000@gmail.co', 'Venkatraman G', 'xdcfghyujiokpl[', 5);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int(255) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `fname`, `lname`, `mail`, `password`) VALUES
(1, 'Varunsimha', 'M P', 'varunsimha@gmail.com', '$2y$12$CABMo8ND0vk.wHcEnVeWd.SNuHV2BKwOd5yf7tYQPsjv7CoUbM3MC'),
(2, 'Varunsimha M P', '123456789012', 'varun@gmail.com', '$2y$12$4KNDCtnB/yR2/ghuD4cdFOs88DAt0n7qdpSFAyq50/EMROYRTyU6K'),
(3, 'Varunsimha', 'p', 'simha@gmail.com', '$2y$12$2PtPa9oJRkBLZMyV6JZz2ubvy.AXvjmcFalyTWAaWLeoDGcJrbUNC');

-- --------------------------------------------------------

--
-- Table structure for table `purchasehistory`
--

CREATE TABLE `purchasehistory` (
  `pid` int(255) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `quantity` int(100) NOT NULL,
  `srate` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `status` varchar(50) NOT NULL,
  `cash` varchar(20) NOT NULL,
  `dateandtime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchasehistory`
--

INSERT INTO `purchasehistory` (`pid`, `mail`, `sname`, `quantity`, `srate`, `amount`, `status`, `cash`, `dateandtime`) VALUES
(61, 'venky@gmail.com', 'Fogg Scent', 7, 500, 3500, 'Delivered', '', '2022-01-27 14:55:17'),
(62, 'venky@gmail.com', 'Parle G', 4, 10, 40, '', '', '2022-01-19 08:30:01'),
(64, 'simha123@gmail.com', 'Fogg Scent', 2, 500, 1000, '', '', '2022-01-21 14:12:54'),
(65, 'simha123@gmail.com', 'Harpic', 1, 60, 60, '', '', '2022-01-21 14:12:54'),
(66, 'venky100000@gmail.com', 'Fogg Scent', 2, 500, 1000, '', '', '2022-01-25 07:36:00'),
(67, 'venky100000@gmail.com', 'Soft &amp; Creamy Paneer', 2, 300, 600, '', '', '2022-01-25 07:38:38'),
(68, 'simha@gmail.com', 'Parle G', 2, 10, 20, 'Delivered', '', '2022-01-27 15:23:10'),
(69, 'simha@gmail.com', 'Fogg Scent', 6, 500, 3000, 'Delivered', '', '2022-01-27 15:25:08'),
(71, 'simha@gmail.com', 'Parle G', 1, 10, 10, 'To be Deliver', '', '2022-01-27 15:31:28'),
(72, 'simha@gmail.com', 'TATA Tea', 7, 100, 700, 'To be Deliver', '', '2022-01-28 08:51:17'),
(73, 'simha@gmail.com', 'Toor Dal', 1, 400, 400, 'To be Deliver', '', '2022-01-28 08:51:17'),
(75, 'simha@gmail.com', 'Fogg Scent', 5, 500, 2500, 'To be Deliver', 'Cash On Delivery', '2022-01-28 08:55:00');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(255) NOT NULL,
  `stype` varchar(100) NOT NULL,
  `sname` varchar(100) DEFAULT NULL,
  `simage` varchar(255) DEFAULT NULL,
  `srate` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `stype`, `sname`, `simage`, `srate`) VALUES
(5, 'Personal Care', 'Fogg Scent', '4a.jpeg', 500),
(6, 'Personal Care', 'Villain Snake', '4b.jpeg', 600),
(7, 'Personal Care', 'Pears', '4d.jpeg', 350),
(8, 'Snacks and Beverages', 'TATA Tea', '3a.jpeg', 100),
(9, 'Snacks and Beverages', 'Sunfeast Nice', '3b.jpeg', 20),
(10, 'Snacks and Beverages', 'Parle G', '3c.jpeg', 10),
(11, 'Cooking Essential', 'Toor Dal', '2a.jpeg', 400),
(12, 'Cooking Essential', 'Nandini Paneer', '2b.jpeg', 250),
(13, 'Cooking Essential', 'Soft &amp; Creamy Paneer', '2c.jpeg', 300),
(14, 'Household Care', 'Harpic', '1a.jpeg', 60),
(15, 'Household Care', 'Presto', '1b.jpeg', 70),
(16, 'Household Care', 'Amber Gold', '1c.jpeg', 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`id`,`mail`);

--
-- Indexes for table `customerdetails`
--
ALTER TABLE `customerdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customerid`
--
ALTER TABLE `customerid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchasehistory`
--
ALTER TABLE `purchasehistory`
  ADD PRIMARY KEY (`pid`,`mail`) USING BTREE;

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`,`stype`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `card`
--
ALTER TABLE `card`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `customerdetails`
--
ALTER TABLE `customerdetails`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customerid`
--
ALTER TABLE `customerid`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `purchasehistory`
--
ALTER TABLE `purchasehistory`
  MODIFY `pid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
